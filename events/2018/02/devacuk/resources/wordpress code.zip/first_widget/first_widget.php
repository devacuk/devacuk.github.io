<?php 


/*
Plugin Name: First Widget
Description: Yeah I am the first widget
*/


class first_widget extends WP_Widget {

	function __construct() {
		$widget_ops = array( 'description' => __('I am a widget') );
		parent::__construct( 'first_widget', __('First Widget'), $widget_ops);	
	}

	function widget($args, $instance) {
		echo "I am a widget";
	}

	function form($instance) {		
		echo "nothing to see here";
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;			
		return $instance;	
	}
	
}

function first_widget_display() {
	register_widget( 'first_widget' );
}
add_action( 'widgets_init', 'first_widget_display', 1 );