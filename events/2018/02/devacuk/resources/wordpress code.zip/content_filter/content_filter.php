<?php
/**
 * @package Hello_Dolly
 * @version 1.6
 */
/*
Plugin Name: Content Filter
Description: Changes content
*/

function content_filter_change($content){
	return $content . " hello";
}

add_filter("the_content", "content_filter_change");
