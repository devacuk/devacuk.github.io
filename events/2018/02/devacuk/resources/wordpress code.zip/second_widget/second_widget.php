<?php 


/*
Plugin Name: Second Widget
Description: Yeah I am the second widget
*/


class second_widget extends WP_Widget {

	function __construct() {
		$widget_ops = array( 'description' => __('I am a widget with potential') );
		parent::__construct( 'second_widget', __('Second Widget'), $widget_ops);	
	}

	function widget($args, $instance) {
		echo $instance['message'];
	}

	function form($instance) {		
		echo '<p><label for="' . $this->get_field_id("message") .'">Message:</label>';
		echo '<input id="' . $this->get_field_id("message") .'" type="text" name="' . $this->get_field_name("message") . '" value="' . $instance['message'] . '" size="35" /></p>';
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;		
		$instance['message'] = $new_instance['message'];	
		return $instance;
	}
	
}

function second_widget_display() {
	register_widget( 'second_widget' );
}
add_action( 'widgets_init', 'second_widget_display', 1 );