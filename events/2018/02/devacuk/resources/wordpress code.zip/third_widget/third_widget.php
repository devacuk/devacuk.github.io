<?php 


/*
Plugin Name: Third Widget
Description: Yeah I am the Third widget
*/


class third_widget extends WP_Widget {

	function __construct() {
		$widget_ops = array( 'description' => __('I am almost a proper widget') );
		parent::__construct( 'third_widget', __('Third Widget'), $widget_ops);	
	}

	function widget($args, $instance) {

		?><section class="widget widget_third">
			<h2 class="widget-title">Third Widget</h2>
			<p><?PHP echo $instance['message']; ?></P>
		</section><?PHP	
		
	}

	function form($instance) {	

		if(!isset($instance['message'])){
			$instance['message'] = "Add message here";
		}
	
		echo '<p><label for="' . $this->get_field_id("message") .'">Message:</label>';
		echo '<input id="' . $this->get_field_id("message") .'" type="text" name="' . $this->get_field_name("message") . '" value="' . $instance['message'] . '" size="35" /></p>';
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;		
		$instance['message'] = $new_instance['message'];	
		return $instance;
	}
	
}

function third_widget_display() {
	register_widget( 'third_widget' );
}
add_action( 'widgets_init', 'third_widget_display', 1 );