<?PHP

	/*
		Plugin Name: Basic Custom Post Type
		Description: Basic custom posts
	*/

	class basic_custom_post_type{
	
		function __construct(){
			add_action("init", array($this, "create"));
		}
	
		function create(){
	
			$labels = array(
				'name' => 'Basic Post',
				'singular_name' => 'Basic Post',
				'add_new' => 'Add new Basic Post',
				'add_new_item' => 'Add Basic Post',
				'edit_item' => 'Edit Basic Post',
				'new_item' => 'New Basic Post',
				'all_items' => 'All Basic Posts',
				'view_item' => 'View Basic Posts',
				'search_items' => 'Search Basic Post',
				'not_found' =>  'No Basic Posts found',
				'not_found_in_trash' => 'No Basic Posts found in trash', 
				'parent_item_colon' => '',
				'menu_name' => 'Basic Post'
			);
				
			$args = array(
				'labels' => $labels,
				'public' => true,
				'show_ui' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'rewrite' => false,
				'supports' => array('title','editor'),
				'menu_position' => 99,
				'exclude_from_search' => true,
				'publically_queryable' => true,
				'taxonomies' => array('category','post_tag'),
			);
		
			register_post_type( 'basic_post' , $args );

		}	
	
	}
	
	$basic_custom_post_type = new basic_custom_post_type();
	